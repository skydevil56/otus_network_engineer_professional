Данный набор скриптов предназначен для получения значений параметров rtt, jitter и loss при помощи утилиты ping до определенного хоста (get_rtt_jitter_loss.py write_params_to_file --address <адрес_хоста>) посредством SNMP.

1. Скрипт с параметрами 'get_rtt_jitter_loss.py write_params_to_file --address <адрес_хоста>' запускает утилиту ping, получает значения параметров rtt, jitter и loss и пишет их в файл:

/opt/snmp_monitoring/snmp_extend/get_rtt_jitter_loss/rtt_jitter_loss.info

Данный скрипт с указанными параметрами нужно запускать по расписанию через cron.

Если пингуемый хост недоступен, то в файл 'rtt_jitter_loss.info' будут записаны значения -1, -1, 100 соответственно и exit code будет равен 1.

2. Скрипт с параметрами 'get_rtt_jitter_loss.py print_parameter_values --parameter_name <имя_параметра>' предназначен для получения значений параметров rtt, jitter и loss из файла:

/opt/snmp_monitoring/snmp_extend/get_rtt_jitter_loss/rtt_jitter_loss.info

посредством SNMP.

Скрипт с параметрами 'get_rtt_jitter_loss.py print_parameter_values --parameter_name <имя_параметра>' может быть запущен с одним из параметров: "rtt", "jitter", "loss".
Запуск скрипта производится по SNMP запрошу сервисом SNMPD.

Полученные значения скрипт пишет в stdout. Если пингуемый хост недоступен, то exit code равен 1. Если информация в файле устарела (определяется переменной THRESHOLD в скрипте) никаких значений не выводится, а код возврата равен 2.
