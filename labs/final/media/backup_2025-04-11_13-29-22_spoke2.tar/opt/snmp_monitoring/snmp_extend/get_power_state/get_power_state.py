#!/usr/bin/python3
import argparse
import os
import sys
import syslog
import subprocess as sp
import configparser
import re
import atexit
import time


"""
Script uses 'pms' and 'pwr_tst' utilities output and makes a decision about power state for each supply
"""
#################################
# 'pms' utility output EXAMPLE: #
#################################

# Full 'pms' output when both supplies are fine:
# ****************************************************************
# ** Lanner Electronics Inc.  2019-07-05
# ** PMBUS utility  Ver, 1.0 for NCB-5210
# ****************************************************************
# <<<<< Power Information: >>>>>
# Power Module 1 Power Mode:AC Power Mode
# Power Module 1 SN:SA190J811935001408
# Power Module 2 Power Mode:AC Power Mode
# Power Module 2 SN:SA190J811935001406
# 
# ================= Power Module 1  =================
# Power Module Status:
# 12V: 12.328             5Vsb: 5.250
# Fan Speed: 4296         Temp1: 34       Temp2: 35
# 
# ================= Power Module 2  =================
# Power Module Status:
# 12V: 12.328             5Vsb: 5.234
# Fan Speed: 5096         Temp1: 33       Temp2: 36
#
# Full 'pms' output when one supply is down:
# ****************************************************************
# ** Lanner Electronics Inc.  2019-07-05
# ** PMBUS utility  Ver, 1.0 for NCB-5210
# ****************************************************************
# <<<<< Power Information: >>>>>
# Power Module 1 Power Mode:AC Power Mode
# Power Module 1 SN:SA190J811935001408
# Power Module 2 Power Mode:AC Power Mode
# Power Module 2 SN:SA190J811935001406
# 
# ================= Power Module 1  =================
# Power Module Status:
# 12V: 12.125             5Vsb: 5.266
# Fan Speed: 5896         Temp1: 36       Temp2: 38
# 
# ================= Power Module 2  =================
# Power Module Status:
# Unit not providing power to the output.
# POWER_GOOD# present.
# 12V: 0.000              5Vsb: 2.828
# Fan Speed: 0    Temp1: 37       Temp2: 41
# 
# ====================================================
# PMBUS Value fail
#
# Full 'pms' output when one supply is missing:
# ****************************************************************
# ** Lanner Electronics Inc.  2019-07-05
# ** PMBUS utility  Ver, 1.0 for NCB-5210
# ****************************************************************
# Power Module 1 PMBUS fail!
# <<<<< Power Information: >>>>>
# Power Module 2 Power Mode:AC Power Mode
# Power Module 2 SN:SA190J811935001406
# 
# ================= Power Module 2  =================
# Power Module Status:
# 12V: 12.188             5Vsb: 5.250
# Fan Speed: 6800         Temp1: 37       Temp2: 39
# 
# 'indexes_and_strings_for_decisions' should be a list of tuples
# these tuples will have element 0 as power module index
# and element 1 as a string according to which decision will be made


#####################################
# 'pwr_tst' utility output EXAMPLE: #
#####################################

# Full 'pwr_tst' output when both supplies are fine:
# === Lanner platform miscellaneous utility ===
# MB-8896 Redundant Power Supply V1.1 2019-02-19
# 
# Power supply 1/2 ....Normal state
#
# Full 'pwr_tst' output when one supply is down:
# MB-8896 Redundant Power Supply V1.1 2019-02-19
# 
# Power supply 1 ....Normal state
# Power supply 2 ....Wrong state


# syslog will take messages with 'Monitoring (get_power_state.py)' in them as identificator
SYSLOG_PREFIX = 'Monitoring ({})'.format(os.path.basename(__file__))
POWER_STATE_HEADER = "power_state"
POWER_STATE_FILE='/opt/snmp_monitoring/snmp_extend/get_power_state/power_state.info'
# Using for syncronize access between extend (reader) and cron (writer) scripts.
POWER_STATE_TMP_FILE='{}.tmp'.format(POWER_STATE_FILE)

THRESHOLD = 3600 # 1 hour

def log_close_explicit():
    syslog.closelog()

atexit.register(log_close_explicit)


class argparse_logger(argparse.ArgumentParser):
    def error(self, message):
        """
        Rewritten 'error' function from 'ArgumentParser' to log to syslog too
        """
        syslog.syslog(syslog.LOG_ERR, message)
        super().error(message)


def parse_args():
    """
    Argument parser
    """
    parser = argparse_logger(description='Writes power states to file / Print power states from file')
    group = parser.add_mutually_exclusive_group(required=True) # 'required' == at least one should be set (but must be only)
    group.add_argument('--write',
                       action='store_true')
    group.add_argument('--print',
                       action='store_true')
    parsed_args = parser.parse_args()
    return parsed_args


def run_local_command(command):
    # Run the process
    proc = sp.Popen(command, shell=True, stdout=sp.PIPE)
    # Wait for the process to finish (for 15 seconds)
    (stdout, _) = proc.communicate(timeout=15)
    return proc.returncode, stdout.decode().rstrip()


def is_up_to_date(timestamp):
    current_sec = int(time.time())
    diff_sec = current_sec - timestamp
    
    if diff_sec < THRESHOLD:
        return True
    else:
        return False


def load_pwr_drv_module():
    rc, output = run_local_command("/usr/sbin/modprobe pwr_drv")
    if rc != 0:
        syslog.syslog(syslog.LOG_ERR,
                      'ERROR: Unable to load pwr_drv kernel module, modprobe exit code: {}'.format(rc))
        return False
    return True


def run_util():
    rc, full_product_name = run_local_command('/usr/sbin/dmidecode -s system-product-name')
    if rc != 0:
        syslog.syslog(syslog.LOG_ERR,
                      'ERROR: Unable to get product name via dmidecode, exit code: {}'.format(rc))
        return '', ''
    
    if 'NCA-5210' in full_product_name:
        util = 'pms'
    elif 'FW-8894' in full_product_name:
        util = 'pwr_tst'
        # pwr_tst utility requires pwr_drv kernel module
        if not load_pwr_drv_module():
            return '', ''
    else:
        syslog.syslog(syslog.LOG_ERR,
                      'ERROR: hardware product is not supported')
        return '', ''
    
    rc, output = run_local_command(util)
    if rc != 0:
        syslog.syslog(syslog.LOG_ERR,
                      'ERROR: {} utility exited with error code {}'.format(util, rc))
        return util, ''
    
    return util, output


# Function takes utility name and it's output and returns list of "up"/"down" decisions for each supply
def parse_util_output(util_name, util_output):
    decisions = []

    # parse utility output
    if util_name == 'pms':
        # Lookup "'pms' utility output EXAMPLE:"
        indexes_and_strings_for_decisions = re.findall('\=+\s+Power\s+Module\s+(\d+)\s+\=+\nPower\sModule\sStatus:\n(.+)', util_output)
    elif util_name == 'pwr_tst':
        # Lookup "'pwr_tst' utility output EXAMPLE:"
        indexes_and_strings_for_decisions = re.findall('Power\s+supply\s+(\d|\d\/\d)\s+\.+(\w+)\sstate', util_output)
    else:
        syslog.syslog(syslog.LOG_ERR,
                      'ERROR: Unknown utility {}'.format(util_name))
        return []

    if indexes_and_strings_for_decisions == []:
        syslog.syslog(syslog.LOG_ERR,
                      'ERROR: {} has printed an unknown message: {}'.format(util_name, util_output))
        return []
    else:
        # get decisions if each power supply is in normal state or not
        if util_name == 'pms':
            for index_and_string in indexes_and_strings_for_decisions:
                if 'Unit not providing power to the output' in index_and_string[1]:
                    decisions.append('power_supply_{}_state="down"'.format(index_and_string[0]))
                elif '12V:' in index_and_string[1]:
                    decisions.append('power_supply_{}_state="up"'.format(index_and_string[0]))
        
        elif util_name == 'pwr_tst':
            for index_and_string in indexes_and_strings_for_decisions:
                if index_and_string[1] == 'Normal':
                    if index_and_string[0] == '1/2':
                        decisions.append('power_supply_1_state="up"')
                        decisions.append('power_supply_2_state="up"')
                    else:
                        decisions.append('power_supply_{}_state="up"'.format(index_and_string[0]))
                else:
                    if index_and_string[0] == '1/2':
                        decisions.append('power_supply_1_state="down"')
                        decisions.append('power_supply_2_state="down"')
                    else:
                        decisions.append('power_supply_{}_state="down"'.format(index_and_string[0]))
        
        # If parser could not find any strings that can decide supplies state, supply would get "unknown" state
        # Particularly it can happen if supply is not in device
        # NCA-5210 will show state "down" if supply is not in device
        for i in range(1, 2, 1):
            if 'power_supply_{}_state="down"'.format(i) not in decisions and 'power_supply_{}_state="up"'.format(i) not in decisions:
                decisions.append('power_supply_{}_state="unknown"'.format(i))
    
    return decisions


def write_decisions():
    util_name, util_output = run_util()
    if util_output == '':
        return False
    decisions = parse_util_output(util_name, util_output)
    
    # Program only works with up to 2 supplies for now
    if len(decisions) == 0:
        return False
    elif len(decisions) != 2:
        syslog.syslog(syslog.LOG_ERR,
                      'ERROR: Wrong amount of strings to write into {} file which must not be the case. Please contact script developer'.format(POWER_STATE_FILE))
        return False
    
    decisions_config = configparser.ConfigParser()
    decisions_config[POWER_STATE_HEADER] = {}
    for decision in decisions:
        decision = decision.split('=')
        decisions_config[POWER_STATE_HEADER].update({decision[0]: decision[1]})

    TIMESTAMP = int(time.time())
    decisions_config[POWER_STATE_HEADER].update({"timestamp": str(TIMESTAMP)})

    with open(POWER_STATE_TMP_FILE, 'w') as result_file:
        decisions_config.write(result_file)
    
    os.rename(POWER_STATE_TMP_FILE, POWER_STATE_FILE)
    return True


def print_power_states():
    if not os.path.isfile(POWER_STATE_FILE):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: no such file: '{}'".format(POWER_STATE_FILE))
        return 1

    if os.path.getsize(POWER_STATE_FILE) == 0:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file {} is empty. Update the file using '--write' option in '{}' script".format(POWER_STATE_FILE, __file__))
        return 2

    power_states = configparser.ConfigParser()
    power_states.read(POWER_STATE_FILE)

    if not is_up_to_date(int(power_states[POWER_STATE_HEADER]["timestamp"])):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file ({}) had not been updated for too long. Information is outdated".format(POWER_STATE_FILE))
        return 2
    
    print(power_states[POWER_STATE_HEADER]['power_supply_1_state'])
    print(power_states[POWER_STATE_HEADER]['power_supply_2_state'])
    return 0


def main():
    syslog.openlog(ident=SYSLOG_PREFIX, facility=syslog.LOG_LOCAL7)
    
    args = parse_args()
    if args.write:
        if not write_decisions():
            sys.exit(1)
    
    elif args.print:
        print_rc = print_power_states()
        if print_rc != 0:
            sys.exit(print_rc)
    
    sys.exit(0)


if __name__ == '__main__':
    main()
