#!/usr/bin/python3
import argparse
import syslog
import sys
import os
import subprocess as sp
import configparser
import shutil
import re
import atexit
import time

### User parameters start ###
PING_CMD_TEMPLATE="ping -q -i 0.2 -W 1 -c 25 "
### User parameters end ###
PING_HEADER = 'ping'
# syslog will take messages with 'Monitoring (get_rtt_jitter_loss.py)' in them as identificator
SYSLOG_PREFIX = 'Monitoring ({})'.format(os.path.basename(__file__))
PING_RESULT_FILE = "/opt/snmp_monitoring/snmp_extend/get_rtt_jitter_loss/rtt_jitter_loss.info"

REGEX_PING = r'(\d+)% packet loss.+\nrtt min\/avg\/max\/mdev = .*\/(.*)\/.*\/(.*) ms'

THRESHOLD = 600 # 10 minutes

def log_close_explicit():
    syslog.closelog()

atexit.register(log_close_explicit)


class argparse_logger(argparse.ArgumentParser):
    def error(self, message):
        """
        Rewritten 'error' function from 'ArgumentParser' to log to syslog too
        """
        syslog.syslog(syslog.LOG_ERR, message)
        super().error(message)


def parse_args():
    """
    Argument parser
    """
    parser = argparse_logger(description='Writes statistics from ping to file / Prints specific parameter from it')

    subparsers = parser.add_subparsers(dest='action', help='Available actions')
    subparsers.required = True
    
    write_params_parser = subparsers.add_parser('write_params_to_file', 
                                                help='Write values from parameters specified in file to file for storage')
    write_params_parser.add_argument('--address',
                                     action='store',
                                     dest='address',
                                     default='8.8.8.8',
                                     help='Set IP address to check connectivity to')

    print_parameter_parser = subparsers.add_parser('print_parameter_values', 
                                                   help='For printing parameter value')
    print_parameter_parser.add_argument('--parameter_name',
                                        action='store',
                                        dest='parameter_name',
                                        choices=['loss', 
                                                 'rtt', 
                                                 'jitter'
                                                ],
                                        required=True)
    
    parsed_args = parser.parse_args()
    return parsed_args


def run_local_command(command):
    # Run the process
    proc = sp.Popen(command, shell=True, stdout=sp.PIPE)
    # Wait for the process to finish (for 15 seconds)
    (stdout, _) = proc.communicate(timeout=15)
    return proc.returncode, stdout.decode().rstrip()


def is_up_to_date(timestamp):
    current_sec = int(time.time())
    diff_sec = current_sec - timestamp
    
    if diff_sec < THRESHOLD:
        return True
    else:
        return False


def get_ping_statistics(address):
    ping_command = '{}{}'.format(PING_CMD_TEMPLATE, address)
    rc, ping_output = run_local_command(ping_command)
    if rc != 0:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: ping exited with '{}' code from '{}' command".format(rc, ping_command))
        matches_tuple = ('100', '-1', '-1')
        return matches_tuple
    matches_tuple = re.search(REGEX_PING, ping_output).group(1, 2, 3)
    return matches_tuple


def write_stats_for_address_to_file(result_file, address):
    tmp_file = '{}.tmp'.format(result_file)
    stats_config = configparser.ConfigParser()
    stats = get_ping_statistics(address)
    TIMESTAMP = int(time.time())

    stats_config[PING_HEADER] = {'loss': str(stats[0]),
                                 'rtt': str(stats[1]),
                                 'jitter': str(stats[2]),
                                 'timestamp': str(TIMESTAMP)
                                }

    with open(tmp_file, "w") as f:
        stats_config.write(f)
    # For synchronize reason (atomic operation).
    shutil.move(tmp_file, result_file)


def print_stat(stat_name):
    if not os.path.isfile(PING_RESULT_FILE):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: no such file: '{}'".format(PING_RESULT_FILE))
        return 1

    if os.path.getsize(PING_RESULT_FILE) == 0:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file {} is empty. Update the file using 'write_params_to_file' option in '{}' script".format(PING_RESULT_FILE, __file__))
        return 2

    stats = configparser.ConfigParser()
    stats.read(PING_RESULT_FILE)

    if not is_up_to_date(int(stats[PING_HEADER]["timestamp"])):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file ({}) had not been updated for too long. Information is outdated".format(PING_RESULT_FILE))
        return 2

    print(stats[PING_HEADER][stat_name])
    return 0


def main():
    syslog.openlog(ident=SYSLOG_PREFIX, facility=syslog.LOG_LOCAL7)
    args = parse_args()
    
    if args.action == 'print_parameter_values':
        print_rc = print_stat(args.parameter_name)
        if print_rc != 0:
            sys.exit(print_rc)
    elif args.action == 'write_params_to_file':
        if not write_stats_for_address_to_file(PING_RESULT_FILE, args.address):
            sys.exit(1)


if __name__ == '__main__':
    main()
