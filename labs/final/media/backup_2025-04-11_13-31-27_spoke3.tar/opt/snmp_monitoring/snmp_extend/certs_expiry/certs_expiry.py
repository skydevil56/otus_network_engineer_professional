#!/usr/bin/python3
import argparse
import sys
import os
import syslog
import subprocess as sp
import re
import datetime
import shutil
import json
from typing import Tuple
import atexit

# syslog will take messages with 'Monitoring (certs_expiry.py)' in them as identificator
SYSLOG_PREFIX = 'Monitoring ({})'.format(os.path.basename(__file__))
LOCAL_CERT_INFO_FILE = '/opt/snmp_monitoring/snmp_extend/certs_expiry/local_certs.info'
THRESHOLD = 3600*25 # 25 hours


def log_close_explicit():
    syslog.closelog()

atexit.register(log_close_explicit)


class argparse_logger(argparse.ArgumentParser):
    def error(self, message):
        """
        Rewritten 'error' function from 'ArgumentParser' to log to syslog too
        """
        syslog.syslog(syslog.LOG_ERR, message)
        super().error(message)


def parse_args():
    """
    Argument parser
    """
    parser = argparse_logger(description='Get certificate info')

    subparsers = parser.add_subparsers(dest='action', help='Available actions')
    subparsers.required = True

    write_parser = subparsers.add_parser('write_params_to_file', help='For writing files')
    print_parser = subparsers.add_parser('print_parameter_values', help='For reading files')

    print_parser.add_argument('--parameter_name',
                              action='store',
                              dest='option',
                              choices=['indexes', 'days'],
                              required=True,
                              help='Print local certificate indexes (not cert_mgr IDs!) or days until expiry')

    return parser.parse_args()


def run_command(command: str) -> Tuple[bool, str]:
    """
    Runs command and gets return code and output
    """
    # Run the process
    proc = sp.Popen(command, shell=True, stdout=sp.PIPE, stderr=sp.PIPE)
    # Wait the process
    (stdout, _) = proc.communicate()
    return proc.returncode, stdout.decode().rstrip()


def is_up_to_date(timestamp):
    dt = datetime.datetime.now()
    current_sec = int(dt.timestamp())
    diff_sec = current_sec - timestamp

    if diff_sec < THRESHOLD:
        return True
    else:
        return False


def write_local_cert_info_to_file(file: str) -> bool:
    """
    Executes 'cert_mgr show -i <index>' sequentially
    and writes info about local certificates to specified file
    """
    output_index = 0
    cert_index = 0
    local_certs_info = {"cert_data": []}
    while True:
        cert_index += 1
        exit_code, stdout = run_command('cert_mgr show -i {}'.format(cert_index))
        if exit_code:
            syslog.syslog(syslog.LOG_ERR,
                          "ERROR: 'cert_mgr show -i {}' has returned non-zero exit code".format(cert_index))
            return False
        else:
            # If program reaches the first remote certificate, it is time to break
            # Since there are no possible local certificates after that.
            # Next condition means that <index> is bigger, than what certificate table contains
            # The end of the table is reached.
            # If program reaches the first CRL, it is time to break
            # Since there are no possible local certificates after that.
            if re.match('\d+ Status: remote', stdout) \
                    or re.match('User error: \d+ exceeds number of objects', stdout) \
                    or re.match('\d+ CRL Issuer', stdout) is not None:
                break
            # We do not need trusted certificate info for now
            # So we just skip them
            elif re.match('\d+ Status: trusted', stdout) is not None:
                continue

            if re.match('\d+ Status: local', stdout) is not None:
                output_index += 1

                expiry_date = re.search('Valid to:\s+(.*)\n', stdout).group(1)
                # "Sun Aug 23 14:17:52 2020"
                expiry_datetime = datetime.datetime.strptime(expiry_date, '%a %b %d %H:%M:%S %Y')
                days_until_expiry = (expiry_datetime - datetime.datetime.now()).days

                local_cert_info = {"index": output_index, "days_until_expiry": days_until_expiry}
                local_certs_info["cert_data"].append(local_cert_info)

    dt = datetime.datetime.now()
    TIMESTAMP = int(dt.timestamp())
    local_certs_info.update({"timestamp": TIMESTAMP})

    local_certs_info_json = json.dumps(local_certs_info, indent=4)

    temp_file = '{}.tmp'.format(file)
    with open(temp_file, 'w') as output_file:
        output_file.write(local_certs_info_json + '\n')

    shutil.move(temp_file, file)

    return True


def print_info(file: str, option: str) -> bool:
    """
    Parses file created using 'write'
    and prints either only indexes
    or only days until expiry according to option ("index" or "days_until_expiry").
    Prints nothing and exits with code 2 if information is outdated (based on THRESHOLD value)
    """
    if os.path.isfile(file) is False:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file {} does not exist. Create it using 'write_params_to_file' option in '{}' script".format(file, __file__))
        sys.exit(1)

    if os.path.getsize(file) == 0:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file {} is empty. Update the file using 'write_params_to_file' option in '{}' script".format(file, __file__))
        sys.exit(2)

    with open(file, 'r') as read_file:
        cert_data = json.load(read_file)

    if not is_up_to_date(cert_data["timestamp"]):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file ({}) had not been updated for too long. Information is outdated".format(LOCAL_CERT_INFO_FILE))
        sys.exit(2)

    options_list = []
    if option:
        for entry in cert_data["cert_data"]:
                options_list.append(entry[option])

    for opt in options_list:
        print(opt)

    return True


def main():
    syslog.openlog(ident=SYSLOG_PREFIX, facility=syslog.LOG_LOCAL7)
    args = parse_args()

    if args.action == 'write_params_to_file':
        if not write_local_cert_info_to_file(LOCAL_CERT_INFO_FILE):
            sys.exit(1)

    if args.action == 'print_parameter_values':
        if args.option == 'indexes':
            print_info(LOCAL_CERT_INFO_FILE, "index")
        elif args.option == 'days':
            print_info(LOCAL_CERT_INFO_FILE, "days_until_expiry")
        else:
            syslog.syslog(syslog.LOG_ERR,
                          "ERROR: Fault argument in '--parameter_name'. Can only be 'indexes' or 'days'")

    sys.exit(0)


if __name__ == '__main__':
    main()
