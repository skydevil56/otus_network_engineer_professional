# Запуск скрипта
1. **certs_expiry.py write_params_to_file** запускается по расписанию в cron и пишет информацию из вывода команд **cert_mgr show -i <id>**, где 'id' это идентификаторы локальных сертификатов, в следующий файл:
```
/opt/snmp_monitoring/snmp_extend/certs_expiry/local_certs.info
```
Пример содержимого файла local_certs.info (JSON):
```
{
    "cert_data": [
        {
            "index": "2",
            "days_until_expiry": 76
        },
        {
            "index": "3",
            "days_until_expiry": 364
        }
    ],
    "timestamp": 1668771873
}
```
В разделе "cert_data" содержится информация о локальных сертификатах: "index" - номер сертификата в выводе **cert_mgr show**, а "days_until_expiry" - количество дней до его истечения. "timestamp" содержит дату (в секундах) последнего обновления содержимого в файле.

2. **certs_expiry.py print_parameter_values --parameter_name {indexes, days}** запускается по соответствующему snmp запросу и выводит последовательно либо значения индексов, либо соответствующее им количество дней до истечения локального сертификата.
Примеры выводов (2 сертификата):
```
root@sterragate:~# /opt/snmp_monitoring/snmp_extend/certs_expiry/certs_expiry.py print_parameter_values --parameter_name indexes
2
3
root@sterragate:~# /opt/snmp_monitoring/snmp_extend/certs_expiry/certs_expiry.py print_parameter_values --parameter_name days
76
364
```
Если содержимое файла не обновлялось дольше порогового значения (определяется переменной THRESHOLD в скрипте) никаких значений не выводится, а код возврата равен 2.

# Логирование
Логирование происходит в facility local7 (файл /var/log/cspvpngate.log по умолчанию) при помощи syslog. При логировании указывается название скрипта и суть ошибки.
Пример:
```
Aug 16 15:26:15 sterragate certs_expiry.py: "ERROR: 'cert_mgr show -i 4' has returned non-zero exit code"
```
