# Запуск скрипта
1. **get_power_state.py --write** запускается по расписанию в cron и пишет информацию о статусе блоков питания в следующей файл:
```
/opt/snmp_monitoring/snmp_extend/get_power_state/power_state.info
```
Пример содержимого файла power_state.info:
```
[power_state]
power_supply_1_state = "up"
power_supply_2_state = "up"
timestamp = 1674465421
```
Статус блоков питания может принимать одно из следущих значений:
 - up - блок питания работает нормально
 - down - блок питания не работает
 - unknown - блок питания находится в неизвестном состоянии (в случае с NCA-5210 такой вывод возможен при его отсутствии)

timestamp содержит отметку времени последнего обновления информации в данном файле, в секундах.

Примечание 1: на данный момент поддерживаются платформы NCA-5210 и FW-8894.  
Примечание 2: на данный момент даже если в устройстве есть только один блок питания, в файл будет выведено 2 значения.

2. **get_power_state.py --print** запускается по соответствующему SNMP запросу из snmpd и пишет в stdout состояния первого и второго блоков питания последовательно с переносом строки. Пример вывода:
```
root@sterragate:~# /opt/snmp_monitoring/snmp_extend/get_power_state/get_power_state.py --print
"up"
"up"
```

В скрипте предусмотрена обработка следующих ситуаций, в зависимости от которых будет отличаться вывод и код выхода:

- Нормальная ситуация:  
stdout: <N>  
exit code: 0  

- Информация в файле не обновлялась дольше порогового значения (задается переменной THRESHOLD в скрипте, значение в секундах):  
stdout: отсутствует  
exit code: 2  

- Внутренняя ошибка скрипта:  
stdout: отсутствует  
exit code: 1  

# Логирование
Логирование происходит в facility local7 (файл /var/log/cspvpngate.log по умолчанию) при помощи syslog. При логировании указывается название скрипта и суть ошибки.
Пример:
```
Jan 23 12:55:06 sterragate Monitoring (get_power_state.py): ERROR: Statistics file (/opt/snmp_monitoring/snmp_extend/get_power_state/power_state.info) had not been updated for too long. Information is outdated
```
