#!/usr/bin/python3
import argparse
import subprocess as sp
import json
import syslog
import sys
import os
import shutil
import re
from typing import Any, Tuple, Dict
import atexit

# syslog will take messages with 'Monitoring (ipsm_iface_stats.py)' in them as identificator
SYSLOG_PREFIX = 'Monitoring ({})'.format(os.path.basename(__file__))
BASE_PATH = '/opt/snmp_monitoring/snmp_extend/ipsm_iface_stats'
DPDK_TELEMETRY_SCRIPT_NAME = "dpdk-telemetry.py"


def log_close_explicit():
    syslog.closelog()

atexit.register(log_close_explicit)


"""
Executable file:
  - writes needed parameters for all interfaces, specified in config file, to file
  - prints either all IPSM port numbers
  - prints specified parameter for all these interfaces (last both by accessing file to which they were written)

EXAMPLES:
Config file contents (<parameter_group> <parameter_name>):
root@sterragate:~# cat stats_needed.conf
{
    "/ipsm/port_stats": {
        "pci_id": {
            "may_be_absent": false
            ...
        },    
        "sent_total": {
            "may_be_absent": false
        }
    },
    "/ethdev/stats": {
        "ipackets": {
            "may_be_absent": true
        }
    }
}

Writing specified parameters to file:
root@sterragate:/opt/snmp_monitoring/snmp_extend/ipsm_iface_stats# ./ipsm_iface_stats.py write_params_to_file --params_file stats_needed.conf --stored_values_file vals

Contents of file with parameters written:
root@sterragate:~# cat vals
{"0": {"/ipsm/port_stats": {"bytes_in": 0}, "/ethdev/stats": {"ibytes": 20006}}, "1": {"/ipsm/port_stats": {"bytes_in": 0}, "/ethdev/stats": {"ibytes": 120}}}

Print IPSM port numbers:
root@sterragate:/opt/snmp_monitoring/snmp_extend/ipsm_iface_stats# ./ipsm_iface_stats.py print_ipsm_iface_ids --stored_values_file vals
0
1

Print '/ethdev/stats ibytes' parameter for IPSM port '0' and '1':
root@sterragate:/opt/snmp_monitoring/snmp_extend/ipsm_iface_stats# ./ipsm_iface_stats.py print_parameter_values --parameter_group /ethdev/stats --parameter_name ibytes --stored_value_file vals
20006
120
"""


class argparse_logger(argparse.ArgumentParser):
    def error(self, message):
        """
        Rewritten 'error' function from 'ArgumentParser' to log to syslog too
        """
        syslog.syslog(syslog.LOG_ERR, message)
        super().error(message)


def parse_args():
    """
    Argument parser
    """
    parser = argparse_logger(description='Writes values from parameters specified in file to file for storage / Prints IPSM interface IDs / Prints IPSM interface parameter vaule')
    
    subparsers = parser.add_subparsers(dest='action', help='Available actions')
    subparsers.required = True
    
    write_params_parser = subparsers.add_parser('write_params_to_file', 
                                                help='Writes values from parameters specified in file to file for storage')

    print_ids_parser = subparsers.add_parser('print_ipsm_iface_ids', help='Print available IPSM interface IDs')
    print_parameter_parser = subparsers.add_parser('print_parameter_values', help='For printing parameter value')
    
    write_params_parser.add_argument('--params_file',
                                     action='store',
                                     dest='params_file',
                                     required=False,
                                     default="{}/parameters.conf".format(BASE_PATH))
    write_params_parser.add_argument('--stored_values_file',
                                     action='store',
                                     dest='stored_values_file',
                                     required=False,
                                     default="{}/ipsm_iface.info".format(BASE_PATH))
    
    print_ids_parser.add_argument('--stored_values_file',
                                  action='store',
                                  dest='stored_values_file',
                                  required=False,
                                  default="{}/ipsm_iface.info".format(BASE_PATH))
    
    print_parameter_parser.add_argument('--parameter_group',
                                        action='store',
                                        dest='parameter_group',
                                        help='Specify parameter group',
                                        required=True)
    print_parameter_parser.add_argument('--parameter_name',
                                        action='store',
                                        dest='parameter_name',
                                        help='Specify parameter name',
                                        required=True)
    print_parameter_parser.add_argument('--stored_values_file',
                                         action='store',
                                         dest='stored_values_file',
                                         required=False,
                                         default="{}/ipsm_iface.info".format(BASE_PATH))
    
    parsed_args = parser.parse_args()
    
    return parsed_args


def run_command(command: str) -> Tuple[bool, str]:
    """
    Runs command and gets return code and output
    """
    # Run the process
    proc = sp.Popen(command, shell=True, stdout=sp.PIPE, stderr=sp.PIPE)
    # Wait the process
    (stdout, _) = proc.communicate()
    return proc.returncode, stdout.decode().rstrip()


def get_dpdk_to_ipsm_ports_map() -> Dict[int, int]:
    """"
    Function returns boolean exit status and DPDK to IPSM interfaces dictionary map
    """
    list_dpdk_ifaces_command = 'echo "/ethdev/list" | {}'.format(DPDK_TELEMETRY_SCRIPT_NAME)
    exit_code, stdout = run_command(list_dpdk_ifaces_command)
    
    if exit_code:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: {} has returned non-zero exit code".format(list_dpdk_ifaces_command))
        return {}
    
    if not re.match('{\"/ethdev/list\": \[(\d+, )*\d+\]}', stdout):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: '/ethdev/list' yielded unexpected results: {}".format(stdout))
        return {}
    dpdk_ifaces_list = json.loads(stdout)['/ethdev/list'] # DPDK interfaces are numbers
    
    dpdk_to_ipsm_ports_map = {}
    for iface in dpdk_ifaces_list:
        port_stats_command = 'echo "/ipsm/port_stats,{}" | {}'.format(iface, DPDK_TELEMETRY_SCRIPT_NAME)
        exit_code, stdout = run_command(port_stats_command)
        if exit_code:
            syslog.syslog(syslog.LOG_ERR,
                          "ERROR: {} has returned non-zero exit code".format(port_stats_command))
            return {}
        if not re.match('{\"/ipsm/port_stats\": {.*\"ipsm_port_id\": \d+.*}}',stdout):
            syslog.syslog(syslog.LOG_ERR,
                          "ERROR: '/ipsm/port_stats' for {} yielded unexpected results: {}".format(iface, stdout))
            return {}
        dpdk_to_ipsm_ports_map[iface] = json.loads(stdout)['/ipsm/port_stats']['ipsm_port_id']
    
    return dpdk_to_ipsm_ports_map


def get_all_params_and_ports_map() -> Tuple[Dict[int, int], Dict[int, Dict[str, Dict[str, Any]]]]:
    """
    Function gets IMPS/DPDK interfaces map dictionary
    And all available parameters to dictionary
    """
    dpdk_to_ipsm_ports_map = get_dpdk_to_ipsm_ports_map()
    if dpdk_to_ipsm_ports_map == {}:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: DPDK to IPSM ports map is empty")
        return {},{}
    
    all_stats_dict = {}
    for dpdk_iface_id in dpdk_to_ipsm_ports_map:
        ipsm_iface_id = dpdk_to_ipsm_ports_map[dpdk_iface_id]
        all_stats_dict[ipsm_iface_id] = {}
        
        stats_groups_list = ['/ipsm/port_stats', '/ethdev/stats', '/ethdev/xstats', '/ethdev/info', '/ethdev/link_status']
        for group in stats_groups_list:
            command = 'echo "{},{}" | {}'.format(group, dpdk_iface_id, DPDK_TELEMETRY_SCRIPT_NAME)
            exit_code, stdout = run_command(command)
            if exit_code:
                syslog.syslog(syslog.LOG_ERR,
                              "ERROR: {} has returned non-zero exit code".format(command))
                return dpdk_to_ipsm_ports_map,{}
            if not re.match('{\"' + group + '\": {.*}}', stdout):
                syslog.syslog(syslog.LOG_ERR,
                              "ERROR: '{}' for {} yielded unexpected results: {}".format(group, dpdk_iface_id, stdout))
                return dpdk_to_ipsm_ports_map,{}
            all_stats_dict[ipsm_iface_id].update(json.loads(stdout))
    
    return dpdk_to_ipsm_ports_map, all_stats_dict


def filter_parameters_by_file(needed_params: Dict[str, Dict[str, Dict[str, Any]]], 
                              dpdk_to_ipsm_ports_map: Dict[int, int], 
                              all_stats_dict: Dict[int, Dict[str, Dict[str, Any]]]) -> Dict[int, Dict[str, Dict[str, Any]]]:
    """
    Function filters parameters by rules, which were set in 'needed_params'
    """
    stats_dict = {}
    for _, ipsm_iface_id in dpdk_to_ipsm_ports_map.items():
        stats_dict[ipsm_iface_id] = {}
        for group in needed_params:
            for parameter in needed_params[group]:
                if 'may_be_absent' in needed_params[group][parameter]:
                    param_optional = needed_params[group][parameter]['may_be_absent']
                else:
                    param_optional = False
                
                if group in all_stats_dict[ipsm_iface_id]:
                    if parameter in all_stats_dict[ipsm_iface_id][group]:
                        if not group in stats_dict[ipsm_iface_id]:
                            stats_dict[ipsm_iface_id][group] = {}
                        stats_dict[ipsm_iface_id][group].update({parameter: all_stats_dict[ipsm_iface_id][group][parameter]})
                    elif not param_optional:
                        syslog.syslog(syslog.LOG_ERR,
                                      "ERROR: unable to find '{}' parameter in '{}' group for interface id '{}'".format(parameter, group, ipsm_iface_id))
                        return {}
                else:
                    syslog.syslog(syslog.LOG_ERR,
                                  "ERROR: unable to find '{}' group".format(group))
                    return {}
    return stats_dict



def write_stats_to_file(stats_needed_file: str, stored_values_file: str) -> bool:
    """
    Writes stats, specified in config file, for all interfaces.
    stats_needed_file file must contain certain JSON structure.
    EXAMPLE:
    {
        "/ipsm/port_stats": {
            "pci_id": {
                "may_be_absent": false
                ...
            },
            ...
        },
        ...
    }
    ...
    """
    dpdk_to_ipsm_ports_map, all_stats_dict = get_all_params_and_ports_map()
    if dpdk_to_ipsm_ports_map == {} or all_stats_dict == {}:
        return False
    
    if not os.path.isfile(stats_needed_file):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: no such file: '{}'".format(stats_needed_file))
        return False

    with open(stats_needed_file, 'r') as read_file:
        try:
            needed_params = json.load(read_file)
        except:
            syslog.syslog(syslog.LOG_ERR,
                          "ERROR: could not load '{}' file. It probably has wrong format".format(stats_needed_file))
            return False
    
    stats_dict = filter_parameters_by_file(needed_params, dpdk_to_ipsm_ports_map, all_stats_dict)
    if stats_dict == {}:
        return False
    
    temp_stored_values_file = '{}.tmp'.format(stored_values_file)
    with open(temp_stored_values_file, 'w') as write_file:
        json.dump(stats_dict, write_file)
    
    # Simple solution for read/write problem (move is elemental operation)
    shutil.move(temp_stored_values_file, stored_values_file)
    
    return True


def print_ispm_iface_ids(params_file: str) -> bool:
    """
    Prints all IPSM interfaces (in DPDK interface order)
    """
    if not os.path.isfile(params_file):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: no such file: '{}'".format(params_file))
        return False
    
    if os.path.getsize(params_file) == 0:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR:  Statistics file '{}' is empty. Update the file using 'write_params_to_file' option in '{}' script".format(params_file, __file__))
        return False


    with open(params_file, 'r') as read_file:
        param_values = json.load(read_file)
    
    for ipsm_iface_id in param_values:
        print(ipsm_iface_id)
    
    return True


def print_param(param_group: str, param_name: str, params_file: str) -> bool:
    """
    Prints specified parameter of specified group for all interfaces
    """
    if not os.path.isfile(params_file):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: no such file: '{}'".format(params_file))
        return False
    
    if os.path.getsize(params_file) == 0:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR:  Statistics file '{}' is empty. Update the file using 'write_params_to_file' option in '{}' script".format(params_file, __file__))
        return False


    with open(params_file, 'r') as read_file:
        param_values = json.load(read_file)
    
    for ipsm_iface_id in param_values:
        # Group or parameter absence is generally not an error
        # If we treat it as an error and return, we will not get any value for interface for which it probably exists
        # Though seting it to None is a really crude way of getting rid of the problem and it should be changed
        if param_group not in param_values[ipsm_iface_id]:
            syslog.syslog(syslog.LOG_WARNING,
                          "WARNING: could not find parameter group '{}' in interface '{}' in file '{}'".format(param_group,
                                                                                                                ipsm_iface_id,
                                                                                                                params_file))
            print(None)
            continue
        if param_name not in param_values[ipsm_iface_id][param_group]:
            syslog.syslog(syslog.LOG_WARNING,
                          "WARNING: could not find parameter '{}' in group '{}' in interface '{}' in file '{}'".format(param_name,
                                                                                                                     param_group,
                                                                                                                     ipsm_iface_id,
                                                                                                                     params_file))
            print(None)
            continue
        
        print(param_values[ipsm_iface_id][param_group][param_name])
    return True


def main():
    syslog.openlog(ident=SYSLOG_PREFIX, facility=syslog.LOG_LOCAL7)
    args = parse_args()
    
    if args.action == 'write_params_to_file':
        if not write_stats_to_file(args.params_file, args.stored_values_file):
            sys.exit(1)
    
    elif args.action == 'print_ipsm_iface_ids':
        if not print_ispm_iface_ids(args.stored_values_file):
            sys.exit(1)
    
    elif args.action == 'print_parameter_values':
        if not print_param(args.parameter_group, args.parameter_name, args.stored_values_file):
            sys.exit(1)
    
    else:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: fault argument '{}' has been passed to script".format(args.action))
        sys.exit(1)
    
    sys.exit(0)

if __name__ == '__main__':
    main()
