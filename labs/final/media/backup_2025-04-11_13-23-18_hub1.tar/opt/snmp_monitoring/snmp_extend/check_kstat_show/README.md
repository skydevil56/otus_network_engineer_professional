# Запуск скрипта
1. **check_kstat_show.py write_params_to_file** запускается по расписанию в cron и пишет информацию из вывода команды **kstat_show** в следующий файл:
```
/opt/snmp_monitoring/snmp_extend/check_kstat_show/kstat_show.info
```
Пример содержимого файла kstat_show.info:
```
[kstat_show]
IPSEC_IN_PACKETS=26659.0
IPSEC_OUT_PACKETS=26659.0
IPSEC_IN_DROPPED_PACKETS=0.0
IPSEC_OUT_DROPPED_PACKETS=0.0
HIGH_PRIO_DROPPED_PACKETS=0.0
LOW_PRIO_DROPPED_PACKETS=0.0
IPSEC_TOTAL_PASSED_PACKETS=53318.0
IPSEC_TOTAL_DROPPED_PACKETS=0.0
PRIO_TOTAL_DROPPED_PACKETS=0.0
IPSEC_DROP_PERCENTAGE=0.0
PRIO_DROP_PERCENTAGE=0.0
TIMESTAMP=1663844281

```
Где:
 - IPSEC_IN_PACKETS - число принятых IPsec пакетов
 - IPSEC_OUT_PACKETS - число отправленных IPsec пакетов
 - IPSEC_IN_DROPPED_PACKETS - число потерянных входящих IPsec пакетов
 - IPSEC_OUT_DROPPED_PACKETS - число потерянных исходящих IPsec пакетов
 - HIGH_PRIO_DROPPED_PACKETS - число потреянных IPsec пакетов с меткой high priority
 - LOW_PRIO_DROPPED_PACKETS - число потреянных IPsec пакетов с меткой low priority
 - IPSEC_TOTAL_PASSED_PACKETS - общее число нормально обработанных IPsec пакетов
 - IPSEC_TOTAL_DROPPED_PACKETS - общее число потерянных IPsec пакетов
 - PRIO_TOTAL_DROPPED_PACKETS - общее число потерянных IPsec пакетов с метками high priority и low priority
 - IPSEC_DROP_PERCENTAGE - процент потерянных IPsec пакетов
 - PRIO_DROP_PERCENTAGE - процент потерянных IPsec пакетов с метками high priority и low priority
 - TIMESTAMP - отметка времени последнего обновления информации в данном файле, в секундах

Примечание 1: некоторые из этих параметров можно получить по соответствующим SNMP запросам, подробнее в документации:
http://doc.s-terra.ru -> С-Терра Шлюз -> С-Терра Шлюз 5.0 (4.3, 4.2) -> Мониторинг -> Выдача статистики -> Список переменных MIB, выдаваемых по SNMP

Примечание 2: для С-Терра Шлюз DP статистика high priority и low priority packets drops недоступна. В этом случае относящиеся к ним параметры будут иметь значение None.

2. **check_kstat_show.py print_parameter_values --parameter_name {HIGH_PRIO_DROPPED_PACKETS, LOW_PRIO_DROPPED_PACKETS, PRIO_TOTAL_DROPPED_PACKETS, PRIO_DROP_PERCENTAGE, IPSEC_DROP_PERCENTAGE, IPSEC_TOTAL_PASSED_PACKETS, IPSEC_TOTAL_DROPPED_PACKETS}** запускается по соответствующему SNMP запросу и выводит значение соответсвующего параметра.
Пример вывода:
```
root@sterragate:~# /opt/snmp_monitoring/snmp_extend/check_kstat_show/check_kstat_show.py print_parameter_values --parameter_name IPSEC_TOTAL_PASSED_PACKETS
53318.0
```

В скрипте предусмотрена обработка следующих ситуаций, в зависимости от которых будет отличаться вывод и код выхода:

- Нормальная ситуация:  
stdout: <N>  
exit code: 0  

- Информация в файле не обновлялась дольше порогового значения (задается переменной THRESHOLD в скрипте, значение в секундах):  
stdout: отсутствует  
exit code: 2  

- Внутренняя ошибка скрипта:  
stdout: отсутствует  
exit code: 1  

# Логирование
Логирование происходит в facility local7 (файл /var/log/cspvpngate.log по умолчанию) при помощи syslog. При логировании указывается название скрипта и суть ошибки.
Пример:
```
Sep 22 11:30:00 sterragate Monitoring (check_kstat_show.py): ERROR: Statistics file (/opt/snmp_monitoring/snmp_extend/check_kstat_show/kstat_show.info) had not been updated for too long. Information is outdated
```
