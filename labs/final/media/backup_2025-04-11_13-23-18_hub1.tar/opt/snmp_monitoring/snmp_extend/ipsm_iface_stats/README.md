# Запуск скрипта
1. **ipsm_iface_stats.py write_params_to_file** запускается по расписанию в cron и записывает значения параметров, указанных в файле **parameters.conf** в следующий файл:
```
/opt/snmp_monitoring/snmp_extend/ipsm_iface_stats/ipsm_iface.info
```
Пример содержимого файла ipsm_iface.info (формат JSON):
```
{"0": {"/ipsm/port_stats": {"pci_id": "83:00.0", "sent_total": 0}, "/ethdev/stats": {"ipackets": 18, ..., "imissed": 0}, "/ethdev/xstats": {"tx_q0_drop_total": 0, "tx_q0_drop_too_many_segs": 0}}, "1": {"/ipsm/port_stats": {"pci_id": "84:00.0", "sent_total": 0}, "/ethdev/stats": {"ipackets": 2, ..., "imissed": 0}, "/ethdev/xstats": {"tx_q0_drop_total": 0, "tx_q0_drop_too_many_segs": 0}}}
```

**Формат содержимого файла parameters.conf**

Внутри файла parameters.conf должна быть структура JSON следующего формата (комментарии не поддерживаются):
**{<группа>: {<имя_параметра>: {[<настройка>: <значение>]}, ...}, ...}**

 - При указании опции **"may_be_absent": true** переменная будет игнорироваться при ее отсутствии в файле ipsm_iface.info. В противном случае при отсутствии параметра в файле скрипт будет логировать ошибку (см. Логирование).

Пример:
```
{
  "/ipsm/port_stats": {
    "sent_total": {
      "may_be_absent": false
    },
    "recv_total": {
      "may_be_absent": false
    },
    "drop_total": {
      "may_be_absent": false
    }
  },
  "/ethdev/stats": {
    "ipackets": {
      "may_be_absent": true
    },
    "opackets": {
      "may_be_absent": true
    }
  }
}
```

2. **ipsm_iface_stats.py print_ipsm_iface_ids** запускается по соответствующему snmp запросу и выводит последовательно значения индексов IPSM интерфейсов (на каждой новой строке), читая их из файла. По умолчанию читается файл **ipsm_iface.info**, в который по умолчанию пишет **write_params_to_file**. Файл должен быть сформирован при помощи **write_params_to_file** заблаговременно.

Пример вывода (4 порта):
```
root@sterragate:~# /opt/snmp_monitoring/snmp_extend/ipsm_iface_stats/ipsm_iface_stats.py print_ipsm_iface_ids
0
1
2
3
```

3. **ipsm_iface_stats.py print_parameter_values --parameter_group <группа> --parameter_name <имя_параметра>** запускается по соответствующему snmp запросу и выводит последовательно значения указанного параметра **<имя_параметра>** из соответствующей группы **<группа>** для IPSM интерфейсов (на каждой новой строке). По умолчанию параметр читается из файла **ipsm_iface.info**, в который по умолчанию пишет **write_params_to_file**. Файл должен быть сформирован при помощи **write_params_to_file** заблаговременно.

Допустимые значения переменной **<группа>**:
```
/ipsm/port_stats
/ethdev/stats
/ethdev/xstats
/ethdev/info
/ethdev/link_status
```
Пример вывода параметров (каждый следующий параметр соответствует следующему порту из вывода "print_ipsm_iface_ids"):
```
root@sterragate:~# /opt/snmp_monitoring/snmp_extend/ipsm_iface_stats/ipsm_iface_stats.py print_parameter_values --parameter_group /ipsm/port_stats --parameter_name pci_id
83:00.0
84:00.0
85:00.0
86:00.0
```


# Логирование
Логирование происходит в facility local7 (файл /var/log/cspvpngate.log по умолчанию) при помощи syslog. При логировании указывается название скрипта и суть ошибки.
Пример:
```
Aug 16 15:26:15 sterragate ipsm_iface_stats.py: ERROR: unable to find 'tx_q0_tx_ring_ful' parameter in '/ethdev/xstats' group
```
