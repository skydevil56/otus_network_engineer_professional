#!/usr/bin/python3
import os
import argparse
import sys
import syslog
import time
import configparser
import shutil
import subprocess as sp
import atexit


KSTAT_FILE = "/opt/snmp_monitoring/snmp_extend/check_kstat_show/kstat_show.info"
KSTAT_HEADER = "kstat_show"
THRESHOLD = 180
# syslog will take messages with 'Monitoring (check_kstat_show.py)' in them as identificator
SYSLOG_PREFIX = 'Monitoring ({})'.format(os.path.basename(__file__))


def log_close_explicit():
    syslog.closelog()

atexit.register(log_close_explicit)


class argparse_logger(argparse.ArgumentParser):
    def error(self, message):
        """
        Rewritten 'error' function from 'ArgumentParser' to log to syslog too
        """
        syslog.syslog(syslog.LOG_ERR, message)
        super().error(message)


def parse_args():
    """
    Argument parser
    """
    parser = argparse_logger(description='Writes parameters from kstat_show to file / Prints parameters from that file')

    subparsers = parser.add_subparsers(dest='action', help='Available actions')
    subparsers.required = True
    
    write_params_parser = subparsers.add_parser('write_params_to_file', 
                                                help='Write values from all parameters to file')
    print_parameter_parser = subparsers.add_parser('print_parameter_values', help='For printing parameter value')
    
    print_parameter_parser.add_argument('--parameter_name',
                                        action='store',
                                        dest='parameter_name',
                                        choices=['IPSEC_TOTAL_PASSED_PACKETS', 
                                                 'IPSEC_TOTAL_DROPPED_PACKETS', 
                                                 'LOW_PRIO_DROPPED_PACKETS', 
                                                 'HIGH_PRIO_DROPPED_PACKETS', 
                                                 'PRIO_TOTAL_DROPPED_PACKETS', 
                                                 'IPSEC_DROP_PERCENTAGE', 
                                                 'PRIO_DROP_PERCENTAGE'],
                                        required=True)
    
    parsed_args = parser.parse_args()
    return parsed_args


def run_local_command(command):
    # Run the process
    proc = sp.Popen(command, shell=True, stdout=sp.PIPE)
    # Wait for the process to finish (for 15 seconds)
    (stdout, _) = proc.communicate(timeout=15)
    return proc.returncode, stdout.decode().rstrip()


def write_to_kstat_file(stats, tmp_file, kstat_file):
    kstat_config = configparser.ConfigParser()
    kstat_config[KSTAT_HEADER] = {}
    for stat in stats:
        kstat_config[KSTAT_HEADER].update({str(stat): str(stats[stat])})

    with open(tmp_file, "w") as f:
        kstat_config.write(f)
    
    shutil.move(tmp_file, kstat_file)


def get_kstat_statistics():
    command = "/usr/bin/kstat_show"
    
    rc, output = run_local_command(command)
    if rc != 0:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: kstat_show exited with error code {}".format(str(rc)))
        return rc, ''
    
    kstat_show_lines = output.split("\n")
    return rc, kstat_show_lines


def update_statistics_file(kstat_file):
    rc, kstat_show_lines = get_kstat_statistics()
    if rc != 0:
        return False
    
    statistics = {
                  "IPSEC_IN_PACKETS": None,
                  "IPSEC_OUT_PACKETS": None,
                  "IPSEC_IN_DROPPED_PACKETS": None,
                  "IPSEC_OUT_DROPPED_PACKETS": None,
                  "HIGH_PRIO_DROPPED_PACKETS": None,
                  "LOW_PRIO_DROPPED_PACKETS": None,
                  "IPSEC_TOTAL_PASSED_PACKETS": None,
                  "IPSEC_TOTAL_DROPPED_PACKETS": None,
                  "PRIO_TOTAL_DROPPED_PACKETS": None,
                  "IPSEC_DROP_PERCENTAGE": None,
                  "PRIO_DROP_PERCENTAGE": None,
                  "TIMESTAMP": None
                 }
    
    # parse kstat_show output to get statistics.
    #
    # EXAMPLE lines from output:
    # ipsec in drop:    1492
    # ipsec out pkt:    1,38556E+12
    
    for line in kstat_show_lines:
        if "ipsec in pkt" in line:
            statistics["IPSEC_IN_PACKETS"] = line.split("\t")[-1]
        if "ipsec out pkt" in line:
            statistics["IPSEC_OUT_PACKETS"] = line.split("\t")[-1]
        if "ipsec in drop" in line:
            statistics["IPSEC_IN_DROPPED_PACKETS"] = line.split("\t")[-1]
        if "ipsec out drop" in line:
            statistics["IPSEC_OUT_DROPPED_PACKETS"] = line.split("\t")[-1]
        if "high priority packets dropped" in line:
            statistics["HIGH_PRIO_DROPPED_PACKETS"] = line.split("\t")[-1]
        if "low priority packets dropped" in line:
            statistics["LOW_PRIO_DROPPED_PACKETS"] = line.split("\t")[-1]
    
    # convert text values like '8,19071E+14' or '127890' to float numbers
    for stat in statistics:
        if statistics[stat] is not None:
            if "E" in statistics[stat]:
                statistics[stat] = float(statistics[stat].replace("," "."))
            else:
                statistics[stat] = float(statistics[stat])
    
    statistics["IPSEC_TOTAL_PASSED_PACKETS"] = statistics["IPSEC_IN_PACKETS"] + statistics["IPSEC_OUT_PACKETS"]
    statistics["IPSEC_TOTAL_DROPPED_PACKETS"] = statistics["IPSEC_IN_DROPPED_PACKETS"] + statistics["IPSEC_OUT_DROPPED_PACKETS"]
    # when running on Gate DP no priority packet stats are available
    if (statistics["HIGH_PRIO_DROPPED_PACKETS"] is not None) and (statistics["LOW_PRIO_DROPPED_PACKETS"] is not None):
        statistics["PRIO_TOTAL_DROPPED_PACKETS"] = statistics["HIGH_PRIO_DROPPED_PACKETS"] + statistics["LOW_PRIO_DROPPED_PACKETS"]
    
    try:
        statistics["IPSEC_DROP_PERCENTAGE"] = (statistics["IPSEC_TOTAL_DROPPED_PACKETS"] / (statistics["IPSEC_TOTAL_PASSED_PACKETS"] + statistics["IPSEC_TOTAL_DROPPED_PACKETS"])) * 100
    except ZeroDivisionError:
        statistics["IPSEC_DROP_PERCENTAGE"] = 0.0
    
    if (statistics["PRIO_TOTAL_DROPPED_PACKETS"] is not None):
        try:
            statistics["PRIO_DROP_PERCENTAGE"] = (statistics["PRIO_TOTAL_DROPPED_PACKETS"] / (statistics["IPSEC_TOTAL_PASSED_PACKETS"] + statistics["PRIO_TOTAL_DROPPED_PACKETS"])) * 100
        except ZeroDivisionError:
            statistics["PRIO_DROP_PERCENTAGE"] = 0.0
    
    # save current date in seconds
    statistics["TIMESTAMP"] = int(time.time())
    
    # write statistics to file
    write_to_kstat_file(statistics, "{}.tmp".format(kstat_file), kstat_file)
    return True


def print_stat(stat_name):
    if not os.path.isfile(KSTAT_FILE):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: No such file: '{}'. Create it using 'write_params_to_file' option in '{}' script".format(KSTAT_FILE, __file__))
        return 1

    if os.path.getsize(KSTAT_FILE) == 0:
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file {} is empty. Update the file using 'write_params_to_file' option in '{}' script".format(KSTAT_FILE, __file__))
        return 2

    stats = configparser.ConfigParser()
    stats.read(KSTAT_FILE)
    if not is_up_to_date(int(stats[KSTAT_HEADER]["TIMESTAMP"])):
        syslog.syslog(syslog.LOG_ERR,
                      "ERROR: Statistics file ({}) had not been updated for too long. Information is outdated".format(KSTAT_FILE))
        return 2
    print(stats[KSTAT_HEADER][stat_name])
    return 0


def is_up_to_date(timestamp):
    current_sec = int(time.time())
    diff_sec = current_sec - timestamp
    
    if diff_sec < THRESHOLD:
        return True
    else:
        return False


def main():
    syslog.openlog(ident=SYSLOG_PREFIX, facility=syslog.LOG_LOCAL7)
    args = parse_args()
    
    if args.action == 'print_parameter_values':
        print_rc = print_stat(args.parameter_name)
        if print_rc != 0:
            sys.exit(print_rc)
    elif args.action == 'write_params_to_file':
        if not update_statistics_file(KSTAT_FILE):
            sys.exit(1)
    
    sys.exit(0)


if __name__ == '__main__':
    main()
